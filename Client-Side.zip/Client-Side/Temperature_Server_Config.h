// gaurd to prevent including file many time.
#pragma once

// definisions
#define PERIODIC_TIME_STEP			1
#define READING_ELEMENTS_NUMBER		5
