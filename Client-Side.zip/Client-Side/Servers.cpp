 // for future use
/*
//headers
#include "Servers.h"

Servers::Servers() {

}

Servers::Servers(std::string clientChannel, std::string clientIp, std::string clientMacId, int clientPort) {
	this->clientChannel = clientChannel;
	this->clientIp = clientIp;
	this->clientMacId = clientMacId;
	this->clientPort = clientPort;
}

void Servers::setClientChannel(std::string clientChannel) {
	this->clientChannel = clientChannel;
}

std::string Servers::getClientChannel() {
	return this->clientChannel;
}

void Servers::setClientIp(std::string clientIp) {
	this->clientIp = clientIp;
}

std::string Servers::getClientIp() {
	return this->clientIp;
}

void Servers::setClientMacId(std::string clientMacId) {
	this->clientMacId = clientMacId;
}

std::string Servers::getClientMacId() {
	return this->clientMacId;
}

void Servers::setClientPort(int clientPort) {
	this->clientPort = clientPort;
}

int Servers::getClientPort() {
	return this->clientPort;
}

*/