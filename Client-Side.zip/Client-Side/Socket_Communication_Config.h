// gaurd to prevent including file many time.
#pragma once

//definisions
#define CLIENT_CHANNEL "client1"
#define CLIENT_PORT 8020
#define CLIENT_IP "127.0.0.1"
#define CLIENT_MAC_ID "123456"
