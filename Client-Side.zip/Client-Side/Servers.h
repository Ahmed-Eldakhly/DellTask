//for future use

/*// gaurd to prevent including file many time.
#pragma once

// headers
#include <string>

// class prototype
class Servers
{
	public:
		Servers();
		Servers(std::string serverChannel , std::string serverIp , int serverPort);
		void setServerChannel(std::string serverChannel);
		std::string getServerChannel();
		void setServerIp(std::string serverIp);
		std::string getServerIp();
		void setServerPort(int serverPort);
		int getServerPort();

	protected:

	private:
		std::string serverChannel;
		int serverPort;
		std::string serverIp;
		std::string serverMacId;

};
*/

